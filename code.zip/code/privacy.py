from presidio_analyzer import AnalyzerEngine
from presidio_analyzer.recognizer_result import RecognizerResult
import re


class Privacy:

    def __init__(self) -> None:
        pass

    def mask_entities(self, text: str = '', analyzer_results: list = [], allowed_entities: list = []) -> tuple:
        mask_dict = {}
        masked_text = text
        #unusable_entities_list = ['URL']
        entity_count = {}
        
        for result in analyzer_results:
            if isinstance(result, RecognizerResult) and result.entity_type in allowed_entities:
                entity_type = result.entity_type
                start = result.start
                end = result.end
                original_entity = text[start:end]

                # Create a mask for the entity with numbering
                entity_count[entity_type] = entity_count.get(entity_type, 0) + 1
                mask = f"{entity_type}_{entity_count[entity_type]}"
                mask_dict[mask] = original_entity

                # Replace the original entity with the mask in the masked text
                masked_text = masked_text[:start] + mask + masked_text[end:]

        return masked_text, mask_dict

    def unmask_entities(self, masked_text: str = '', mask_dict: dict = {}) -> str:
        for mask, original_entity in mask_dict.items():
            masked_text = re.sub(re.escape(mask), original_entity, masked_text)

        return masked_text
    
    def entity_detector(self, text: str = '') -> list:
        analyzer = AnalyzerEngine()
        analyzer_results = analyzer.analyze(text=text, language="en")

        return analyzer_results