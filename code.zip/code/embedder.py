import requests
import warnings
import configparser

warnings.filterwarnings("ignore")

config = configparser.ConfigParser()
config.read("config.ini")


class EmbeddingGenerator:
    def __init__(self) -> None:
        self.key = config.get("MODEL", "api_key")
        self.url = config.get("MODEL", "embedder_url")

    def text_embedding(self, text: str='') -> list:
        headers = {
            "Content-Type": "application/json",
            "api-key": self.key,
        }

        json_data = {
            "input": text
        }

        try:
            response = requests.post(
                self.url,
                headers=headers,
                json=json_data,
                verify=False,
            )
            if response.status_code == 200:
                embedding = response.json()['data'][0]['embedding']
                return embedding
            else:
                print(f"Request falied with {response.status_code} status code.")
                print(f"Response Body:\n{response.text}")
                return None
        except Exception as e:
            return "Model is unable to produce output. Please try again."
