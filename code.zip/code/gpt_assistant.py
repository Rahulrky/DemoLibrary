import requests
import warnings
import configparser
import os
import traceback

warnings.filterwarnings("ignore")

config = configparser.ConfigParser()
config.read("config.ini")


class Assistant:
    def __init__(self) -> None:
        self.key = config.get("MODEL", "api_key")
        self.url = config.get("MODEL", "url")
        self.timeout = config.getint("MODEL", "timeout")
        self.api_version = config.get("MODEL", "api_version")

    def completion(
        self,
        prompt: str = "",
        temperature: int = 0.7,
    ) -> str:
        headers = {
            "Content-Type": "application/json",
            "api-key": self.key,
        }

        params = {
            "api-version": self.api_version,
        }
        json_data = {
            "messages": [
                {
                    "role": "system",
                    "content": "You are a helpful assistant",
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            "temperature": temperature,
        }

        try:
            response = requests.post(
                self.url,
                params=params,
                headers=headers,
                json=json_data,
                verify=False,
                timeout=self.timeout,
            )
            result = eval(response.text.replace("null", "''"))
            return result["choices"][0]["message"]["content"]
        except Exception as e:
            return "Model is unable to produce output. Please try again."