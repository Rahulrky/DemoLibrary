import textstat
import language_tool_python


class TextQuality:
    def __init__(self, text: str = "") -> None:
        self.text = text

    @staticmethod
    def flesch_reading_ease(text: str = ""):
        """
        Returns the Flesch Reading Ease Score.

        The following table can be helpful to assess the ease of readability in a document.

        The table is an example of values. While the maximum score is 121.22,
        there is no limit on how low the score can be. A negative score is valid.

        Score	Difficulty
        90-100	Very Easy
        80-89	Easy
        70-79	Fairly Easy
        60-69	Standard
        50-59	Fairly Difficult
        30-49	Difficult
        0-29	Very Confusing

        """
        return textstat.flesch_reading_ease(text)

    @staticmethod
    def flesch_kincaid_grade(text: str = ""):
        """
        Returns the Flesch-Kincaid Grade of the given text.
        This is a grade formula in that a score of 9.3 means that a ninth grader
        would be able to read the document.
        """
        return textstat.flesch_kincaid_grade(text)

    @staticmethod
    def smog_index(text: str = ""):
        """
        Returns the SMOG index of the given text.
        This is a grade formula in that a score of 9.3 means that a
        ninth grader would be able to read the document.

        Texts of fewer than 30 sentences are statistically invalid,
        because the SMOG formula was normed on 30-sentence samples.
        textstat requires at least 3 sentences for a result.
        """
        return textstat.smog_index(text)

    @staticmethod
    def coleman_liau_index(text: str = ""):
        """
        Returns the grade level of the text using the Coleman-Liau Formula.
        This is a grade formula in that a score of 9.3 means that a
        ninth grader would be able to read the document.
        """
        return textstat.coleman_liau_index(text)

    @staticmethod
    def automated_readability_index(text: str = ""):
        """
        Returns the ARI (Automated Readability Index) which outputs a
        number that approximates the grade level needed to comprehend the text.

        For example if the ARI is 6.5, then the grade level to comprehend the text is 6th to 7th grade.
        """
        return textstat.automated_readability_index(text)

    @staticmethod
    def dale_chall_readability_score(text: str = ""):
        """
        Different from other tests, since it uses a lookup table of the most commonly used 3000 English words.
        Thus it returns the grade level using the New Dale-Chall Formula.

        Score	        Understood by
        4.9 or lower	average 4th-grade student or lower
        5.0-5.9	        average 5th or 6th-grade student
        6.0-6.9	        average 7th or 8th-grade student
        7.0-7.9	        average 9th or 10th-grade student
        8.0-8.9	        average 11th or 12th-grade student
        9.0-9.9	        average 13th to 15th-grade (college) student
        """
        return textstat.dale_chall_readability_score(text)

    @staticmethod
    def linsear_write_formula(text: str = ""):
        """
        Returns the grade level using the Linsear Write Formula.
        This is a grade formula in that a score of 9.3 means that a
        ninth grader would be able to read the document.
        """
        return textstat.linsear_write_formula(text)

    @staticmethod
    def gunning_fog(text: str = ""):
        """
        Returns the FOG index of the given text.
        This is a grade formula in that a score of 9.3 means that a
        ninth grader would be able to read the document.
        """
        return textstat.gunning_fog(text)

    @staticmethod
    def text_standard(text: str = ""):
        """
        Based upon all the above tests, returns the estimated school grade level required to understand the text.

        Optional float_output allows the score to be returned as a float. Defaults to False.
        """
        return textstat.text_standard(text)

    @staticmethod
    def reading_time(text: str = "", ms_per_char: float = 14.69):
        """
        Returns the reading time of the given text.

        Assumes 14.69ms per character.
        """
        return textstat.reading_time(text, ms_per_char)

    @staticmethod
    def difficult_words(text: str = ""):
        """
        Returns number of difficult words in text.
        """
        return textstat.difficult_words(text)

    @staticmethod
    def calculate_flesch_reading_ease(text):
        # Calculate the Flesch Reading Ease Score
        score = textstat.flesch_reading_ease(text)

        # Define the difficulty levels
        difficulty_levels = {
            (90, 100): "Very Easy",
            (80, 90): "Easy",
            (70, 80): "Fairly Easy",
            (60, 70): "Standard",
            (50, 60): "Fairly Difficult",
            (30, 50): "Difficult",
            (0, 30): "Very Confusing",
        }

        # Determine the difficulty level based on the score
        difficulty = None
        if score < 0:
            difficulty = "Very Confusing"
        
        elif score > 100:
            difficulty = "Very Easy"

        else:
            for score_range, level in difficulty_levels.items():
                if score >= score_range[0] and score < score_range[1]:
                    difficulty = level
                    break

        # Return the result as a dictionary
        result = {"score": score, "difficulty": difficulty}
        return result

    def text_qaulity_metrices(self):
        return {
            "flesch_reading_ease": TextQuality.flesch_reading_ease(self.text),
            "flesch_reading_ease_dict": TextQuality.calculate_flesch_reading_ease(self.text),
            "flesch_kincaid_grade": TextQuality.flesch_kincaid_grade(self.text),
            "smog_index": TextQuality.smog_index(self.text),
            "coleman_liau_index": TextQuality.coleman_liau_index(self.text),
            "automated_readability_index": TextQuality.automated_readability_index(self.text),
            "dale_chall_readability_score": TextQuality.dale_chall_readability_score(self.text),
            "linsear_write_formula": TextQuality.linsear_write_formula(self.text),
            "gunning_fog": TextQuality.gunning_fog(self.text),
            "text_standard": TextQuality.text_standard(self.text),
            "reading_time": TextQuality.reading_time(self.text),
            "difficult_words": TextQuality.difficult_words(self.text),
        }

    def choosen_metrices(self, text: str = ""):
        tool = language_tool_python.LanguageTool('en-US')
        matches = tool.check(self.text)
        return {
            "flesch_reading_ease_dict": TextQuality.calculate_flesch_reading_ease(self.text),
            "text_standard": TextQuality.text_standard(self.text),
            "reading_time": TextQuality.reading_time(self.text),
            "difficult_words": TextQuality.difficult_words(self.text),
            "grammar_error": len(matches)
        }
    
    # def quality_insights(self, metric_dict: dict = {}):
    #     return f"""
    # The generated text is {metric_dict['flesch_reading_ease_dict']['difficulty']} to read and have a Flesch Reading Ease Score as {metric_dict['flesch_reading_ease_dict']['score']}

    # The generated text can be understood by any individual having minimum knowledege of {metric_dict['text_standard']}

    # The generated text have {metric_dict['difficult_words']} difficult words.

    # The generated text have {metric_dict['grammar_error']} grammatical errors.
    #     """
    def quality_insights(self, metric_list: list = []):
        out_str = ''
         
        if "Reading Ease" in metric_list:
            flesch_reading_ease_dict = TextQuality.calculate_flesch_reading_ease(self.text)
            out_str += f"The generated text is '{flesch_reading_ease_dict['difficulty']}' to read and have a Flesch Reading Ease Score as {flesch_reading_ease_dict['score']}"

        if "Text Standard" in metric_list:
            out_str += f"\n The generated text can be understood by any individual having minimum knowledege of {TextQuality.text_standard(self.text)}"

        if "Difficult words" in metric_list:
            out_str += f"\n The generated text have {TextQuality.difficult_words(self.text)} difficult words."

        if "Grammatical Error" in metric_list:
            tool = language_tool_python.LanguageTool('en-US')
            matches = tool.check(self.text)
            out_str += f"\n The generated text have {len(matches)} grammatical errors."

        return out_str